package com.example.save;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.widget.Toast;


public class DrawView extends View {

    public static int BRUSH_SIZE = 70;
    public static int SCALED_BRUSH_SIZE = 3;
    public static final int DEFAULT_COLOR = Color.BLACK;
    public static final int DEFAULT_BG_COLOR = Color.WHITE;
    private static final float TOUCH_TOLERANCE = 4;

    private float mX, mY, mScaledX, mScaledY;
    private Path mPath, mScaledPath;
    private Paint mPaint, mScaledPaint;
    private Bitmap mBitmap, mScaledBitmap;
    private Canvas mCanvas, mScaledCanvas;
    private String mString;

    public DrawView(Context context) {
        super(context);
        setUpPaint();
    }

    public DrawView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        setUpPaint();
    }

    private void setUpPaint() {
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
        mPaint.setDither(true);
        mPaint.setColor(DEFAULT_COLOR);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeJoin(Paint.Join.ROUND);
        mPaint.setStrokeCap(Paint.Cap.ROUND);
        mPaint.setXfermode(null);
        mPaint.setAlpha(0xff);

        mScaledPaint = new Paint();
        mScaledPaint.setAntiAlias(true);
        mScaledPaint.setDither(true);
        mScaledPaint.setColor(DEFAULT_COLOR);
        mScaledPaint.setStyle(Paint.Style.STROKE);
        mScaledPaint.setStrokeJoin(Paint.Join.ROUND);
        mScaledPaint.setStrokeCap(Paint.Cap.ROUND);
        mScaledPaint.setXfermode(null);
        mScaledPaint.setAlpha(0xff);
    }

    public void initialise (int width,int height) {
        mBitmap = Bitmap.createBitmap(width, width, Bitmap.Config.ARGB_8888);
        mScaledBitmap = Bitmap.createScaledBitmap(mBitmap,24,24,false);

        mCanvas = new Canvas(mBitmap);
        mScaledCanvas = new Canvas(mScaledBitmap);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.save();

        mCanvas.drawColor(DEFAULT_BG_COLOR);
        mPaint.setColor(DEFAULT_COLOR);
        mPaint.setStrokeWidth(BRUSH_SIZE);
        mPaint.setMaskFilter(null);

        mScaledCanvas.drawColor(DEFAULT_BG_COLOR);
        mScaledPaint.setColor(DEFAULT_COLOR);
        mScaledPaint.setStrokeWidth(SCALED_BRUSH_SIZE);
        mScaledPaint.setMaskFilter(null);

        if (mPath != null)
            mCanvas.drawPath(mPath, mPaint);

        if (mScaledPath != null)
            mScaledCanvas.drawPath(mScaledPath,mScaledPaint);

        canvas.drawBitmap(mBitmap, 0, 0, mPaint);
        canvas.drawBitmap(mScaledBitmap, 0, 0, mScaledPaint);

        canvas.restore();
    }

    public void touchStart (float x, float y) {
        mPath = new Path();
        mPath.reset();
        mPath.moveTo(x, y);
        mX = x;
        mY = y;

        float x2 = Math.abs(x*24/mBitmap.getWidth());
        float y2 = Math.abs(y*24/mBitmap.getHeight());

        mScaledPath = new Path();
        mScaledPath.reset();
        mScaledPath.moveTo(x2, y2);
        mScaledX = x2;
        mScaledY = y2;
    }

    public void touchMove (float x, float y) {
        float dx = Math.abs(x - mX);
        float dy = Math.abs(y - mY);
        float x2 = Math.abs(x*24/mBitmap.getWidth());
        float y2 = Math.abs(y*24/mBitmap.getHeight());
        if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
            mPath.quadTo(mX, mY, (x + mX) / 2, (y + mY) / 2);
            mX = x;
            mY = y;

            mScaledPath.quadTo(mScaledX, mScaledY, (x2 + mScaledX) / 2, (y2 + mScaledY) / 2);
            mScaledX = x2;
            mScaledY = y2;
        }
    }

    public void touchUp () {
        mPath = null;
        mScaledPath = null;
    }

    public Bitmap getBitmap(){
        return mScaledBitmap;
    }

    public void setString(String str){
        mString = str;
    }

    public void saveImage () {

        int count = 0;

        File sdDirectory = Environment.getExternalStorageDirectory();
        File subDirectory = new File(sdDirectory.toString() + "/Pictures/Validation/"+mString);

        if (subDirectory.exists()) {
            File[] existing = subDirectory.listFiles();
            for (File file : existing) {
                if (file.getName().endsWith(".jpg") || file.getName().endsWith(".png")) {
                    count++;
                }
            }
        } else {

            subDirectory.mkdir();

        }

        if (subDirectory.exists()) {

            String zeros = "_00";
            if(count + 1 < 10)
                zeros = "_00";
            else if((count + 1 > 9)&&(count + 1 < 100))
                zeros = "_0";
            else if(count + 1 > 99)
                zeros = "_";
            File image = new File(subDirectory, "/" + mString + zeros + String.valueOf(count+1) + ".png");
            FileOutputStream fileOutputStream;

            try {
                fileOutputStream = new FileOutputStream(image);
                mScaledBitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                fileOutputStream.flush();
                fileOutputStream.close();
                Toast.makeText(getContext(), String.valueOf(count), Toast.LENGTH_LONG).show();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } //close the if
    }

}

