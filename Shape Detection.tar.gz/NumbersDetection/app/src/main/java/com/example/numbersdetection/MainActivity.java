package com.example.numbersdetection;

import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.TextView;
import org.tensorflow.lite.Interpreter;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class MainActivity extends AppCompatActivity {

    private DrawView mDrawView;
    private TextView mPredictionTextView;
    private Bitmap mBitmap;
    private byte input[][][] = new byte[1][24][24];
    private float output[][] = new float[1][12];
    private String predictionValue;
    private static int inputSize = 24;
    private float maxValue = 0;

    private final int VERTICAL = 0;
    private final int HORIZONTAL = 1;
    private final int BACK_FLIP = 2;
    private final int BACK_KICK = 3;
    private final int CAPOEIRA = 4;
    private final int DIAGONAL_UP = 5;
    private final int DIAGONAL_DOWN = 6;
    private final int FROND_FLIP = 7;
    private final int FROND_KICK = 8;
    private final int GROUND = 9;
    private final int ROLL = 10;
    private final int TSAKI_TSAN = 11;

    Interpreter tflite;

    private void findIDs(){
        mDrawView = findViewById(R.id.drawView);
        mPredictionTextView = findViewById(R.id.predictionText);
    }

    private void initialiseDrawView(){
        int width = 800;
        int height = 1200;   ///Perfectly i would take the original parameters
        mDrawView.initialise(width,height);
    }

    private void makeTflite(){
        try{
            tflite = new Interpreter(loadModelFile());
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findIDs();
        initialiseDrawView();

        makeTflite();

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        float x = event.getX();
        float y = event.getY() - 120;  /// perfectly i would found other solution

        switch (event.getAction()) {

            case MotionEvent.ACTION_DOWN:
                mDrawView.touchStart(x, y);
                mDrawView.invalidate();
                break;
            case MotionEvent.ACTION_UP:
                mBitmap = mDrawView.getBitmap();
                makeInput();
                predictionValue = getPredict();
                mPredictionTextView.setText(predictionValue);
                mDrawView.touchUp();
                mDrawView.invalidate();
                break;
            case MotionEvent.ACTION_MOVE:
                mDrawView.touchMove(x, y);
                mDrawView.invalidate();
                break;
        }
        return true;
    }

    public void makeInput(){
        byte pixelValue;
        mBitmap = mDrawView.getBitmap();
        for (int i = 0; i < inputSize; i++){
            for (int j = 0; j < inputSize; j++){
                pixelValue = (byte)Math.abs((mBitmap.getPixel(j,i) + 1 )/16777215);
                input[0][i][j] = pixelValue;
            }
        }
    }

    private int getMaxValue(){
        int predict = 0;
        for (int i =0 ; i < 12; i++){
            if (output[0][i] > maxValue) {
                maxValue = output[0][i];
                predict = i;
            }
        }
        System.out.println();
        System.out.println("Max Value is: " + String.valueOf(maxValue));
        System.out.println("for number: " + String.valueOf(predict));
        return predict;
    }

    public String getPredict() {
        String str = "";
        float value = inference();
        if(maxValue < 0.99)
            str = "FAIL";
        else {
            if (value == BACK_FLIP)
                str = "Back-flip";
            else if (value == BACK_KICK)
                str = "Back-kick";
            else if (value == VERTICAL)
                str = "Vertical";
            else if (value == HORIZONTAL)
                str = "Horizontal";
            else if (value == DIAGONAL_DOWN)
                str = "Diagonal-Down";
            else if (value == DIAGONAL_UP)
                str = "Diagonal-Up";
            else if (value == TSAKI_TSAN)
                str = "Tsaki_Tsan";
            else if (value == CAPOEIRA)
                str = "Capoeira";
            else if (value == FROND_FLIP)
                str = "Frond-flip";
            else if (value == FROND_KICK)
                str = "Frond-Kick";
            else if (value == GROUND)
                str = "Ground";
            else if (value == ROLL)
                str = "Roll";
        }
        maxValue = 0;
        return str;
    }

    public float inference(){

        tflite.run(input,output);

        float inferedValue = getMaxValue(); /// find the max value of !!!!!!!!!!!!!!

        return inferedValue;
    }

    private MappedByteBuffer loadModelFile() throws IOException {
        AssetFileDescriptor fileDescriptor = this.getAssets().openFd("lines.tflite");
        FileInputStream fileInputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel = fileInputStream.getChannel();
        long startOffSets = fileDescriptor.getStartOffset();
        long declaredLength = fileDescriptor.getDeclaredLength();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY,startOffSets,declaredLength);
    }

}